import React, { useState, useEffect } from 'react';
import { View, TouchableOpacity, Text, StyleSheet, Image } from 'react-native';

const colors = ['blue', 'lime', 'red', 'yellow', 'cyan', 'orange', 'white', 'violet', 'salmon'];

// Importando as imagens
const gameImage = require('./assets/durante.png');
const firstImage = require('./assets/hello.png');
const errorImage = require('./assets/cry.png');
const venceuImage = require('./assets/happy.png');

export default function GeniusGame() {
  const [sequence, setSequence] = useState([]);
  const [playerSequence, setPlayerSequence] = useState([]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [level, setLevel] = useState(1);
  const [speed, setSpeed] = useState(1000);
  const [flashingIndex, setFlashingIndex] = useState(null);
  const [gameWon, setGameWon] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [difficulty, setDifficulty] = useState(null); // Estado para a dificuldade
  const [maxSequenceLength, setMaxSequenceLength] = useState(10); // Max length da sequência

  useEffect(() => {
    if (isPlaying) playSequence();
  }, [sequence]);

  const generateNextStep = () => Math.floor(Math.random() * 9);

  const startGame = () => {
    setSequence([generateNextStep()]);
    setPlayerSequence([]);
    setIsPlaying(true);
    setLevel(1);
    setGameWon(false);
    setGameOver(false);
  };

  const playSequence = async () => {
    for (let i = 0; i < sequence.length; i++) {
      await new Promise((resolve) => {
        setFlashingIndex(sequence[i]);
        setTimeout(() => {
          setFlashingIndex(null);
          resolve();
        }, speed / 2);
      });
      await new Promise((resolve) => setTimeout(resolve, speed / 2));
    }
  };

  const handlePress = (index) => {
    if (!isPlaying || gameWon || gameOver) return;

    const newPlayerSequence = [...playerSequence, index];
    setPlayerSequence(newPlayerSequence);

    if (newPlayerSequence[newPlayerSequence.length - 1] !== sequence[newPlayerSequence.length - 1]) {
      setIsPlaying(false);
      setGameOver(true);
      return;
    }

    if (newPlayerSequence.length === sequence.length) {
      if (level === maxSequenceLength) {
        setGameWon(true);
        setIsPlaying(false);
      } else {
        setTimeout(() => {
          setLevel(level + 1);
          setSpeed(Math.max(300, speed - 10)); // Ajuste na velocidade
          setSequence([...sequence, generateNextStep()]);
          setPlayerSequence([]);
        }, 500);
      }
    }
  };

  // Função para escolher a dificuldade
  const handleDifficulty = (level) => {
    setDifficulty(level);
    if (level === 'facil') {
      setMaxSequenceLength(10);
      setSpeed(1000);
    } else if (level === 'medio') {
      setMaxSequenceLength(25);
      setSpeed(700);
    } else if (level === 'dificil') {
      setMaxSequenceLength(50);
      setSpeed(500);
    }
    startGame();
  };

  const goToDifficultySelection = () => {
    setGameWon(false);
    setGameOver(false);
    setDifficulty(null); // Limpar a dificuldade para voltar à tela inicial
  };

  return (
    <View style={styles.container}>
      {/* Tela de erro */}
      {gameOver && (
        <View style={styles.errorOverlay}>
          <Text style={styles.errorText}>Erro!</Text>
          <Text style={styles.errorMessage}>😢 Você errou a sequência! 😢</Text>
          <Image source={errorImage} style={styles.image} />
          <TouchableOpacity style={styles.startButton} onPress={goToDifficultySelection}>
            <Text style={styles.startText}>Novo Jogo</Text>
          </TouchableOpacity>
        </View>
      )}

      {/* Tela de vitória */}
      {gameWon ? (
        <View style={styles.winContainer}>
          <Text style={styles.winText}>🎉 Parabéns! Você venceu! 🎉</Text>
          <Image source={venceuImage} style={styles.image} />
          <TouchableOpacity style={styles.startButton} onPress={goToDifficultySelection}>
            <Text style={styles.startText}>Novo Jogo</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <>
          {/* Tela de escolha de dificuldade */}
          {!difficulty && (
            <View style={styles.difficultyContainer}>
              <Text style={styles.title}>Escolha a Dificuldade</Text>
              <TouchableOpacity style={styles.difficultyButton} onPress={() => handleDifficulty('facil')}>
                <Text style={styles.difficultyText}>Fácil</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.difficultyButton} onPress={() => handleDifficulty('medio')}>
                <Text style={styles.difficultyText}>Médio</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.difficultyButton} onPress={() => handleDifficulty('dificil')}>
                <Text style={styles.difficultyText}>Difícil</Text>
              </TouchableOpacity>
            </View>
          )}

          {/* Tela do jogo */}
          {difficulty && (
            <>
              <Text style={styles.title}>Genius</Text>
              <Text style={styles.title}>Nível {level}/{maxSequenceLength}</Text>

              {/* Grade de botões */}
              <View style={styles.grid}>
                {colors.map((color, index) => (
                  <TouchableOpacity
                    key={index}
                    style={[
                      styles.button,
                      { backgroundColor: color },
                      flashingIndex === index ? styles.flashing : {},
                    ]}
                    onPress={() => handlePress(index)}
                  />
                ))}
              </View>

              {/* Exibir imagem antes do jogo iniciar */}
              {!isPlaying && !gameOver && !gameWon && (
                <>
                  <TouchableOpacity style={styles.startButton} onPress={startGame}>
                    <Text style={styles.startText}>Iniciar Jogo</Text>
                  </TouchableOpacity>
                  <Image source={firstImage} style={styles.image} />
                </>
              )}

              {/* Exibir imagem apenas durante o jogo */}
              {isPlaying && !gameOver && !gameWon && (
                <Image source={gameImage} style={styles.image} />
              )}
            </>
          )}
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#660F56',
  },
  title: {
    fontSize: 24,
    color: '#fff',
    marginBottom: 20,
  },
  grid: {
    width: 300,
    height: 300,
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  button: {
    width: 90,
    height: 90,
    margin: 5,
    borderRadius: 10,
  },
  flashing: {
    opacity: 0.4,
  },
  startButton: {
    marginTop: 20,
    padding: 10,
    backgroundColor: 'white',
    borderRadius: 5,
  },
  startText: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  winContainer: {
    alignItems: 'center',
  },
  winText: {
    fontSize: 24,
    color: 'gold',
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
  },
  errorOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1,
    backgroundColor: 'rgba(0, 0, 0, 1)',
  },
  errorText: {
    fontSize: 30,
    color: '#fff',
    fontWeight: 'bold',
  },
  errorMessage: {
    fontSize: 18,
    color: '#fff',
    marginBottom: 20,
  },
  image: {
    width: 190,
    height: 190,
    marginTop: 20,
  },
  difficultyContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 20,
  },
  difficultyButton: {
    marginTop: 10,
    padding: 10,
    backgroundColor: 'white',
    borderRadius: 5,
  },
  difficultyText: {
    fontSize: 18,
    fontWeight: 'bold',
  },
});
